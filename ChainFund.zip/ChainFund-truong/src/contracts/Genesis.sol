//SPDX-License-Identifier: MIT
pragma solidity ^0.8.7;

import "@openzeppelin/contracts/security/ReentrancyGuard.sol";

contract Genesis is ReentrancyGuard {
    address public owner;
    uint public projectTax;
    uint public projectCount;
    // Reduced for local testing: 10 seconds
    uint public payOutDelay = 10;
    statsStruct public stats;
    projectStruct[] projects;

    mapping(address => projectStruct[]) projectsOf;
    mapping(uint => backerStruct[]) backersOf;
    mapping(uint => bool) public projectExist;

    enum statusEnum {
        OPEN,
        APPROVED,
        REVERTED,
        DELETED,
        PAIDOUT
    }

    struct statsStruct {
        uint totalProjects;
        uint totalBacking;
        uint totalDonations;
    }

    struct backerStruct {
        address owner;
        uint contribution;
        uint timestamp;
        bool refunded;
    }

    struct projectStruct {
        uint id;
        address owner;
        address payoutWallet;
        string title;
        string description;
        string imageURL;
        uint cost;
        uint raised;
        uint timestamp;
        uint payOutAt;
        uint expiresAt;
        uint backers;
        statusEnum status;
    }

    modifier ownerOnly(){
        require(msg.sender == owner, "Owner reserved only");
        _;
    }

    event Action (
        uint256 id,
        string actionType,
        address indexed executor,
        uint256 timestamp
    );

    // More specific events for frontend/backend listeners
    event ProjectBacked(uint256 indexed id, address indexed backer, uint256 amount, uint256 timestamp);
    event RefundProcessed(uint256 indexed id, address indexed recipient, uint256 amount, uint256 timestamp);
    event PayoutProcessed(uint256 indexed id, address indexed recipient, uint256 amount, uint256 tax, uint256 timestamp);

    constructor(uint _projectTax) {
        owner = msg.sender;
        projectTax = _projectTax;
    }

    function createProject(
        string memory title,
        string memory description,
        string memory imageURL,
        uint cost,
        uint expiresAt
    ) public returns (bool) {
        require(bytes(title).length > 0, "Title cannot be empty");
        require(bytes(description).length > 0, "Description cannot be empty");
        require(bytes(imageURL).length > 0, "ImageURL cannot be empty");
        require(cost > 0 ether, "Cost cannot be zero");

        projectStruct memory project;
        project.id = projectCount;
        project.owner = msg.sender;
        project.payoutWallet = address(0);
        project.title = title;
        project.description = description;
        project.imageURL = imageURL;
        project.cost = cost;
        project.timestamp = block.timestamp;
        project.expiresAt = expiresAt;

        projects.push(project);
        projectExist[projectCount] = true;
        projectsOf[msg.sender].push(project);
        stats.totalProjects += 1;

        emit Action (
            projectCount++,
            "PROJECT CREATED",
            msg.sender,
            block.timestamp
        );
        return true;
    }

    function updateProject(
        uint id,
        string memory title,
        string memory description,
        string memory imageURL,
        uint expiresAt
    ) public returns (bool) {
        require(msg.sender == projects[id].owner, "Unauthorized Entity");
        require(bytes(title).length > 0, "Title cannot be empty");
        require(bytes(description).length > 0, "Description cannot be empty");
        require(bytes(imageURL).length > 0, "ImageURL cannot be empty");

        projects[id].title = title;
        projects[id].description = description;
        projects[id].imageURL = imageURL;
        projects[id].expiresAt = expiresAt;

        emit Action (
            id,
            "PROJECT UPDATED",
            msg.sender,
            block.timestamp
        );

        return true;
    }

    function deleteProject(uint id) public nonReentrant returns (bool) {
        require(projects[id].status == statusEnum.OPEN, "Project no longer opened");
        require(msg.sender == projects[id].owner, "Unauthorized Entity");

        projects[id].status = statusEnum.DELETED;
        // protect from reentrancy when performing refunds
        performRefund(id);

        emit Action (
            id,
            "PROJECT DELETED",
            msg.sender,
            block.timestamp
        );

        return true;
    }

    function performRefund(uint id) internal {
        // Checks-Effects-Interactions: mark refunded and zero out contribution before external call
        for(uint i = 0; i < backersOf[id].length; i++) {
            address _owner = backersOf[id][i].owner;
            uint _contribution = backersOf[id][i].contribution;

            if(_contribution == 0) continue;

            // effect: mark refunded and zero contribution to prevent reentrancy double-spend
            backersOf[id][i].refunded = true;
            backersOf[id][i].timestamp = block.timestamp;
            backersOf[id][i].contribution = 0;

            // interaction
            payTo(_owner, _contribution);

            emit RefundProcessed(id, _owner, _contribution, block.timestamp);

            stats.totalBacking -= 1;
            stats.totalDonations -= _contribution;
        }
    }

    function backProject(uint id) public payable nonReentrant returns (bool) {
        require(msg.value > 0 ether, "Ether must be greater than zero");
        require(projectExist[id], "Project not found");
        require(projects[id].status == statusEnum.OPEN, "Project no longer opened");
        require(projects[id].owner == address(0), "Donations disabled until owner withdraws rights");

        stats.totalBacking += 1;
        stats.totalDonations += msg.value;
        projects[id].raised += msg.value;
        projects[id].backers += 1;

        backersOf[id].push(
            backerStruct(
                msg.sender,
                msg.value,
                block.timestamp,
                false
            )
        );

        emit ProjectBacked(id, msg.sender, msg.value, block.timestamp);

        emit Action (
            id,
            "PROJECT BACKED",
            msg.sender,
            block.timestamp
        );

        if (projects[id].raised >= projects[id].cost) {
            projects[id].status = statusEnum.APPROVED;
            projects[id].payOutAt = block.timestamp + payOutDelay;
            return true;
        }

        if(block.timestamp >= projects[id].expiresAt) {
            projects[id].status = statusEnum.REVERTED;
            performRefund(id);
            return true;
        }

        return true;
    }

    function performPayout(uint id) internal {
        uint raised = projects[id].raised;
        uint tax = (raised * projectTax) / 100;

        projects[id].status = statusEnum.PAIDOUT;
        address recipient = projects[id].payoutWallet != address(0) ? projects[id].payoutWallet : projects[id].owner;
        payTo(recipient, (raised - tax));
        payTo(owner, tax);

        // no internal bookkeeping required — use address(this).balance for canonical contract balance

        emit PayoutProcessed(id, projects[id].owner, (raised - tax), tax, block.timestamp);

        emit Action (
            id,
            "PROJECT PAID OUT",
            msg.sender,
            block.timestamp
        );
    }

    function renounceProjectOwnership(uint id) public returns (bool) {
        require(projectExist[id], "Project not found");
        require(msg.sender == projects[id].owner, "Unauthorized Entity");
        require(projects[id].owner != address(0), "Already renounced");

        // save current owner as payout wallet for future automatic payout
        projects[id].payoutWallet = projects[id].owner;
        // renounce ownership for the project
        projects[id].owner = address(0);

        emit Action(
            id,
            "PROJECT RENOUNCED",
            msg.sender,
            block.timestamp
        );

        return true;
    }

    // Anyone can call this to trigger payout/refund when conditions are met.
    function triggerAutoPayout(uint id) public nonReentrant returns (bool) {
        require(projectExist[id], "Project not found");

        // if project already paid out or deleted/reverted, nothing to do
        if (projects[id].status == statusEnum.PAIDOUT || projects[id].status == statusEnum.DELETED || projects[id].status == statusEnum.REVERTED) {
            return false;
        }

        // expired without reaching target -> refund
        if (block.timestamp >= projects[id].expiresAt && projects[id].status == statusEnum.OPEN) {
            projects[id].status = statusEnum.REVERTED;
            performRefund(id);
            return true;
        }

        // approved and payout delay reached -> perform payout
        if (projects[id].status == statusEnum.APPROVED && block.timestamp >= projects[id].payOutAt) {
            performPayout(id);
            return true;
        }

        return false;
    }

    function requestRefund(uint id) public nonReentrant returns (bool) {
        // restrict who can trigger refunds to prevent abuse
        require(
            msg.sender == projects[id].owner || msg.sender == owner,
            "Unauthorized Entity"
        );

        // allow owner to mark project as reverted and perform refunds
        projects[id].status = statusEnum.REVERTED;
        // protect from reentrancy when sending refunds
        performRefund(id);
        return true;
    }

    function payOutProject(uint id) public nonReentrant returns (bool) {
        require(projects[id].status == statusEnum.APPROVED, "Project not APPROVED");
        require(block.timestamp >= projects[id].payOutAt, "Payout delay not reached");

        // allow owner or project owner to execute payout; protect from reentrancy
        require(
            msg.sender == projects[id].owner || msg.sender == owner,
            "Unauthorized Entity"
        );

        performPayout(id);
        return true;
    }

    function changeTax(uint _taxPct) public ownerOnly {
        projectTax = _taxPct;
    }

    function getProject(uint id) public view returns (projectStruct memory) {
        require(projectExist[id], "Project not found");

        return projects[id];
    }
    
    function getProjects() public view returns (projectStruct[] memory) {
        return projects;
    }
    
    function getBackers(uint id) public view returns (backerStruct[] memory) {
        return backersOf[id];
    }

    // explicit getter for canonical contract balance
    function getInternalBalance() public view returns (uint) {
        return address(this).balance;
    }

    function payTo(address to, uint256 amount) internal {
        (bool success, ) = payable(to).call{value: amount}("");
        require(success);
    }
}